<?php

// Tietokannasta haku
$DATABASE_IMAGES = [
  [
    'id' => 'p1',
    'title' => 'Dog 1',
    'display' => [
      'src' => 'koira-1.jpg',
      'alt' => 'Dog 1',
    ],
  ],
  [
    'id' => 'p2',
    'title' => 'Dog 2',
    'display' => [
      'src' => 'koira-2.jpg',
      'alt' => 'Dog 2',
    ],
  ],
  [
    'id' => 'p3',
    'title' => 'Dog 3',
    'display' => [
      'src' => 'koira-3.jpg',
      'alt' => 'Dog 3',
    ],
  ],
  [
    'id' => 'p4',
    'title' => 'Dog 4',
    'display' => [
      'src' => 'koira-4.jpg',
      'alt' => 'Dog 4',
    ],
  ],
  [
    'id' => 'p5',
    'title' => 'Dog 5',
    'display' => [
      'src' => 'koira-5.jpg',
      'alt' => 'Dog 5',
    ],
  ],
  [
    'id' => 'p6',
    'title' => 'Dog 6',
    'display' => [
      'src' => 'koira-6.jpg',
      'alt' => 'Dog 6',
    ],
  ],
  [
    'id' => 'p7',
    'title' => 'Dog 7',
    'display' => [
      'src' => 'koira-7.jpg',
      'alt' => 'Dog 7',
    ],
  ],
  [
    'id' => 'p8',
    'title' => 'Dog 8',
    'display' => [
      'src' => 'koira-8.jpg',
      'alt' => 'Dog 8',
    ],
  ],
];

?>