<?php
    $title = "Cart";
    include "../templates/header.php";
?>

<main id="shop">
    <h2>Your Shopping Cart</h2>
</main>

<?php
include "../templates/footer.php";
?>